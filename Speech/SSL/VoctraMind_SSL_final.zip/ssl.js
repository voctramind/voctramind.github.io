// VoctraMind SSL — progress tracker

const links = [...document.querySelectorAll('.map-item')];
const sections = links
  .map(link => document.querySelector(link.getAttribute('href')))
  .filter(Boolean);

const timeline = document.querySelector('.timeline');

function updateTracker() {
  if (!links.length || !sections.length || !timeline) return;

  const probe = window.innerHeight * 0.30;

  let current = 0;

  sections.forEach((section, index) => {
    if (section.getBoundingClientRect().top <= probe) {
      current = index;
    }
  });

  links.forEach((link, index) => {
    link.classList.toggle('active', index === current);
    link.classList.toggle('done', index < current);
  });

  const firstDot = links[0].querySelector('.map-dot');
  const currentDot = links[current].querySelector('.map-dot');

  if (!firstDot || !currentDot) return;

  const timelineRect = timeline.getBoundingClientRect();

  const firstY =
    firstDot.getBoundingClientRect().top +
    firstDot.offsetHeight / 2 -
    timelineRect.top;

  const currentY =
    currentDot.getBoundingClientRect().top +
    currentDot.offsetHeight / 2 -
    timelineRect.top;

  timeline.style.setProperty(
    '--progress-height',
    `${Math.max(0, currentY - firstY)}px`
  );
}

links.forEach(link => {
  link.addEventListener('click', event => {
    const target = document.querySelector(link.getAttribute('href'));

    if (!target) return;

    event.preventDefault();

    target.scrollIntoView({
      behavior: 'smooth',
      block: 'start'
    });
  });
});

window.addEventListener('scroll', updateTracker, { passive: true });
window.addEventListener('resize', updateTracker);
window.addEventListener('load', updateTracker);

updateTracker();
